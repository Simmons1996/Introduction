﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SturtzBackupUtility
{
    public class MachineTypes
    {
        public static List<string> SawTypes = new List<string>()
            {
                "VHC",
                "V-Cut",
                "DM-90",
                "SD500",
                "MR-90"
            };
        
        public static List<string> WelderTypes = new List<string>()
            {
                "HSM-TurboFrame",
                "HSM-TurboSash",
                "HSM-PDS",
                "HSM-BDS",
                "HSM-CDS",
                "VSM",
                "VSM-TurboFrame",
                "VSM-TurboSash"
            };

        public static List<int> CleanerTypes = new List<int>()
            {
               //todo....
            };


    }
    public class SawDirectory
    {
        private readonly static string Common = @"D:\Common";
        private readonly static string JetSym_LP = @"D:\JetSym_LP";
        private readonly static string JetView = @"D:\JetView";
        private readonly static string JvsProject = @"D:\JVS_LinPro";

        public static List<string> SawFiles = new List<string>()
            {
                SawDirectory.Common,
                SawDirectory.JetSym_LP,
                SawDirectory.JetView,
                SawDirectory.JvsProject
            };


    }
    class WelderDirectory
    {
        private readonly static string Jetsym_B = @"D:\Jetsym_B";
        private readonly static string Jetsym_W = @"D:\JetSym_W";
        private readonly static string JetView = @"D:\JetView_W";
        private readonly static string JvsProject = @"D:\JVSProject_W";

        public static List<string> WelderFiles = new List<string>()
            {
                WelderDirectory.Jetsym_B,
                WelderDirectory.Jetsym_W,
                WelderDirectory.JetView,
                WelderDirectory.JvsProject
            };


    }
    class CleanerDirectory  //todo....
    {
        public static List<string> CleanerFiles = new List<string>()
        {
            

        };

    }
}


