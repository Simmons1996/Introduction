﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SturtzBackupUtility
{
    public class ComboBox
    {
        
            Dictionary<int, string> Combosource = new Dictionary<int, string>();
            public int Value { get; set; }
            public string Text { get; set; }
            public override string ToString() { return Text; }
            public static List<string> ControllerTypes = new List<string>()
            {
                "JC 24x",
                "JC 64x",
                "JC 340",
                "JC 350",
                "JC 360",
                "JC 940MC",
                "JC 360MC",
                "JC 970MC",
                "JC 365",
                "JC 365MC"
               
            };
            public static List<int> ControllerEnumerations = new List<int>()
            {
                9,
                10,
                24,
                25,
                26,
                27,
                28,
                35,
                53,
                54

            };
    }
}
