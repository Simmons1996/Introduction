﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SturtzBackupUtility
{
    public class Connections
    {
        public class SqlServer
        {   //future development

            public static string DB_DATA = "Data Source=localhost;Integrated Security=False;User Id=StuertzSQLAdmin;Password=StuertzSQLAdmin;Connection Timeout=10;Initial Catalog=DB_DATA_Cleaner;";
            public static string DB_SETUP = "Data Source=localhost;Integrated Security=False;User Id=StuertzSQLAdmin;Password=StuertzSQLAdmin;Connection Timeout=10;Initial Catalog=DB_SETUP_Cleaner;";
            public static string DB_EVENTS = "Data Source=localhost;Integrated Security=False;User Id=StuertzSQLAdmin;Password=StuertzSQLAdmin;Connection Timeout=10;Initial Catalog=DB_EVENTS_Cleaner;";
        }

        public class MachineConnections
        {
            public static string Saw_IP = "192.168.37.101";
            public static string WelderMainPLC_IP = "192.168.37.101";
            public static string WelderTurboPLC_IP = "192.168.37.109";
            public static string Cleaner_IP = "192.168.37.113";
            public static string Buffer_IP = "192.168.37.104";
            public static string MAIN = "MAIN";
            public static string TURBO = "TURBO";
            public static string ETH = "ETH";
            public static string BUFFER = "BUFFER";


            public static List<string> IpAddresses = new List<string>()
            {
                MachineConnections.Saw_IP,
                MachineConnections.WelderMainPLC_IP,
                MachineConnections.WelderTurboPLC_IP,
                MachineConnections.Cleaner_IP,
                MachineConnections.Buffer_IP
            

            };
        }
    }
  
}
