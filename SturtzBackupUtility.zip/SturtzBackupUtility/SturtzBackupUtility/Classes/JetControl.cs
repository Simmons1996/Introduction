﻿#define OPC_Client

using SturtzBackupUtility;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;



//**************************************************************************************************//
//                                   Jetcontrol communication class                                 //
//                                                                                                  //
//  Author: R.Roy                          Date: 2019.04.10                           Version: 2.1  //
//****************************************************************************************************
namespace SturtzBackupUtility
{

    public class JetControl : IDisposable
    {
        DispatcherTimer oPacDriveCommTimer = new DispatcherTimer();
        int PacDriveLastCommCounter = 0;
        bool PacDriveIsOnline = false;
        bool PacDriveLastIsOnline = true;
        private static Dictionary<string, JetControl> PacDriveList = new Dictionary<string, JetControl>();
        public static Dictionary<string, JetControl> JetControlList = new Dictionary<string, JetControl>();
        
        

        private bool disposed = false;

        public static readonly string JetControlMainID = "MAIN";
        
        private int ControllerReconnectInterval_ms = 10000;  //Default: 30000
        private int ControllerTimeout_ms = 250;              //Default:  4000
        private int TagGroupDataChangeUpdateTime_ms = 100;   //Default:   500

        private JET32XLib.JVJet32X Controller = new JET32XLib.JVJet32X();
#if OPC_Client
        private JVOPCCLIENTMODLib.JVOpcClient OPC_Client = new JVOPCCLIENTMODLib.JVOpcClient();
#endif
        public Dictionary<string, JetTag> Tags = new Dictionary<string, JetTag>();

        //public string JetControlID = "-";
        public string JetControlID = JetControlMainID;

        public bool IsMainController
        {
            get { return (JetControlID == JetControlMainID); }
        }

        public override string ToString()
        {
            return (JetControlID);
        }


        //public bool IsActive = true;
        private bool _IsActive = false;
        public bool IsActive
        {
            get
            {
                //return _IsActive;
                JetControl oJetControl = JetControlList.Values.FirstOrDefault(Item => Item.JetControlID == this.JetControlID);
                if (oJetControl != null)
                {
                    return (oJetControl._IsActive);
                }
                else
                {
                    return (false);
                }
            }
            set
            {
                _IsActive = value;
            }
        }

        public bool IsMessageSystemActive = false;
        public static JetControl MainJetControl
        {
            get
            {
                return (JetControlList.Values.FirstOrDefault(Item => Item.IsMainController == true));
            }
        }
        


        //****************************************************************************************************
        #region Controller Enumerations

        public enum JetControlType
        {
            NoController = -1,

            //PaseE = 0,
            //Mikro = 1,
            //Delta = 2,
            //NanoA = 3,
            //NanoB = 4,
            //NanoC = 5,
            //PcPplcCtrl = 6,
            //NanoD = 7,
            //DeltaCPU2 = 8,
            JetControl24x = 9,
            JetControl64x = 10,
            //JetMoveOem = 11,
            //JetControl800 = 12,
            //JetControl64xSTX = 13,
            //JMD203JC24x = 14,
            //JetControlSoftSTX = 18,
            //JetControlSoftSTXCE = 19,
            //JetControl24xSTX = 20,
            //JMD203JC24xSTX = 21,
            //JVM407 = 22,
            //JX3BNETH = 23,
            JetControl340 = 24,
            JetControl350 = 25,
            JetControl360 = 26,
            JetControl940MC = 27,
            JetControl360MC = 28,
            //JCM350 = 29,
            //JV300JVER = 33,
            //JCM620JVER = 34,
            JetControl970MC = 35,
            JetControl365 = 53,
            JetControl365MC = 54,
            //JetAny = 254,
            //JetUnknown = 255,
            PacDrive_LMC_101 = 255,
        }

        public enum JetControlInterfaceType
        {
            Serial = 0,
            JetWay = 1,
            PCPPLC = 2,
            JetIP = 3,
            JetSTX = 4,
            JetIPSoap = 5,
            JetSTXSoap = 6,
            JetCAN = 7,
            JetCANSTX = 8,
        }

        public enum JetControlState
        {
            Online = 1,
            Offline = 2,
        }

        #endregion
        //****************************************************************************************************

        //****************************************************************************************************
        #region Properties
        private JetControlType _ControllerType = JetControlType.NoController;
        public JetControlType ControllerType
        {
            get { return _ControllerType; }
            set { _ControllerType = value; }
        }

        private string _ControllerIPAddress = "";
        public string ControllerIPAddress
        {
            get { return _ControllerIPAddress; }
            set { _ControllerIPAddress = value; }
        }

        //private bool _IsConnected = false;
        public bool IsConnected
        {
            get
            {
                if (ControllerType == JetControlType.PacDrive_LMC_101)
                {
                    return PacDriveIsOnline;
                }
                else
                {
                    return Controller.IsConnected();
                }
            }
        }

        public bool NoDataChangeOnInit
        {
            get { return Controller.NoOnDataChangeOnInit; }
            set { Controller.NoOnDataChangeOnInit = value; }
        }

        public bool NoStatusChangeOnInit = true;
        private bool StatusChangeInit = false;
        public bool TransferAsynchronously
        {
            get { return Controller.TransferAsynchronously; }
            set { Controller.TransferAsynchronously = value;}
        }
        public bool FireProgressEvents
        {
            get { return Controller.FireProgressEvents; }
            set { Controller.FireProgressEvents = value;}
        }
        public bool ShowProgressDialog
        {
            get { return Controller.ShowProgressDialog; }   
            set { Controller.ShowProgressDialog = value;}
        }
        public uint DataDumpTransferFlags
        {
            get { return Controller.DataDumpTransferFlags;}
            set { Controller.DataDumpTransferFlags = value;}
        }
 
        #endregion
        //****************************************************************************************************

        //****************************************************************************************************
        #region Events

        //
        //****************************************************************************************************
        public delegate void EventHandlerDataChange(JetControl JetControl, string TagName, dynamic RegisterValue);
        public event EventHandlerDataChange OnDataChangeEvent;
        private void Controller_OnDataChange(string bstrItem, int nClientHandle, dynamic bstrValue)
        {
            //if (OnDataChangeEvent != null)
            //{
                dynamic RegisterValue = bstrValue;
                if (Tags.ContainsKey(bstrItem))
                {
                    if (Tags[bstrItem].RegisterType == typeof(int))
                    {
                        RegisterValue = int.Parse(bstrValue);
                    }
                    else if (Tags[bstrItem].RegisterType == typeof(double))
                    {
                        RegisterValue = double.Parse(bstrValue, CultureInfo.CreateSpecificCulture("en-US"));
                    }
                    else if (Tags[bstrItem].RegisterType == typeof(bool))
                    {
                        if (ControllerType == JetControlType.PacDrive_LMC_101)
                        {
                            RegisterValue = (bstrValue == "0") ? false : true;
                        }
                        else
                        {
                            RegisterValue = (bstrValue == "1") ? true : false;
                        }
                    }
                    else if (Tags[bstrItem].RegisterType == typeof(string))
                    {
                        RegisterValue = bstrValue;
                    }
                    //OnDataChangeEvent(this, bstrItem, RegisterValue);
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        OnDataChangeEvent?.Invoke(this, bstrItem, RegisterValue);
                    }));
            }
            //}
        }

        //
        //****************************************************************************************************
        public delegate void EventHandlerChangeStatus(JetControl Controller, JetControlState State, string Description);
        public event EventHandlerChangeStatus OnChangeStatusEvent;
        private void Controller_OnStatusChange(int nStatusCode, string bstrDescription)
        {
            //if (OnChangeStatusEvent != null)
            //{
                if (nStatusCode == 2)
                {
                    StatusChangeInit = true;
                }

                if (!NoStatusChangeOnInit || (NoStatusChangeOnInit && ((StatusChangeInit && nStatusCode == 1) || nStatusCode == 2)))
                {
                    //OnChangeStatusEvent(this, (JetControlState)nStatusCode, bstrDescription);
                    Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                    {
                        OnChangeStatusEvent?.Invoke(this, (JetControlState)nStatusCode, bstrDescription);
                    }));
                }

            //}
        }

        //
        //****************************************************************************************************
        public delegate void EventHandlerError(JetControl Controller, string Code, string Description);
        public event EventHandlerError OnErrorEvent;
        private void Controller_OnError(string bstrErrorCode, string bstrErrorDescription)
        {
            //if (OnErrorEvent != null)
            //{
            //    OnErrorEvent(this, bstrErrorCode, bstrErrorDescription);
            //}
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                OnErrorEvent?.Invoke(this, bstrErrorCode, bstrErrorDescription);
            }));
        }
        //
        //****************************************************************************************************
        public delegate void EventHandlerDataDumpFinished(JetControl Controller, bool Direction, bool Error);
        public event EventHandlerDataDumpFinished OnDataDumpFinishedEvent;
        private void Controller_OnDataDumpFinished(bool Direction, bool Error)
        {
                      
            Application.Current.Dispatcher.BeginInvoke((Action)(() =>
            {
                OnDataDumpFinishedEvent?.Invoke(this,Direction,Error);
                
            }));
        }
        //
        //****************************************************************************************************

        #endregion
        //****************************************************************************************************


        public JetControl(/*string JetControlID = ""*/)
        {
            //if (string.IsNullOrWhiteSpace(JetControlID))
            //{
            //    this.JetControlID = JetControlMainID;
            //}

            Controller.JVOnDataChange += Controller_OnDataChange;
            Controller.OnChangeStatus += Controller_OnStatusChange;
            Controller.OnError += Controller_OnError;
            Controller.OnDataDumpTransferComplete += Controller_OnDataDumpFinished;//doesnt work, plc never fires event
            
#if OPC_Client
            OPC_Client.JVOnDataChange += Controller_OnDataChange;
            OPC_Client.OnError += Controller_OnError;
#endif
        }

        //****************************************************************************************************
        #region CleanUp
        ~JetControl()
        {
            Dispose(false);
        }

        //
        //****************************************************************************************************
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        //
        //****************************************************************************************************
        protected virtual void Dispose(bool disposeManagedResources)
        {
            if (!disposed && disposeManagedResources)
            {
                if (Controller != null)
                {
                    Controller.JVOnDataChange -= Controller_OnDataChange;
                    Controller.OnChangeStatus -= Controller_OnStatusChange;
                    Controller.OnError -= Controller_OnError;
                    Controller.OnDataDumpTransferComplete -= Controller_OnDataDumpFinished;
                    Controller.DisconnectEx(true);

                    Controller = null;
                    //System.Windows.MessageBox.Show("Disposed");
                }

#if OPC_Client
                if (OPC_Client != null)
                {
                    oPacDriveCommTimer.Stop();
                    oPacDriveCommTimer.IsEnabled = false;
                    oPacDriveCommTimer.Tick -= CommStateTimer_Tick;

                    OPC_Client.JVOnDataChange -= Controller_OnDataChange;
                    OPC_Client.OnError -= Controller_OnError;
                    OPC_Client.Disconnect();

                    if (PacDriveList.ContainsKey(ControllerIPAddress))
                    {
                        PacDriveList.Remove(ControllerIPAddress);
                    }

                    OPC_Client = null;
                }
#endif
                disposed = true;
            }
        }
        #endregion
        //****************************************************************************************************

        //****************************************************************************************************
        #region PacDrive Communication WatchDog

        //
        //****************************************************************************************************
        private void CommStateTimer_Tick(object sender, EventArgs e)
        {
            oPacDriveCommTimer.IsEnabled = false;

            if (CheckPacDriveConnection())
            {
                if (!PacDriveLastIsOnline)
                {
                    Console.WriteLine(this.JetControlID + " " + "Online");
                    Controller_OnStatusChange(1, "Online");
                    PacDriveIsOnline = true;
                }
            }
            else
            {
                if (PacDriveLastIsOnline)
                {
                    Console.WriteLine(this.JetControlID + " " + DateTime.Now.ToString("dd.MM.yyyy hh:mm:ss") + " " + "Short time Offline");

                    if (!CheckPacDriveConnection())
                    {
                        Console.WriteLine(this.JetControlID + " " + "Offline");
                        Controller_OnStatusChange(2, "Offline");
                        PacDriveIsOnline = false;
                    }

                }

            }
            PacDriveLastIsOnline = PacDriveIsOnline;

            oPacDriveCommTimer.IsEnabled = true;
        }

        //
        //****************************************************************************************************
        protected bool CheckPacDriveConnection()
        {
            if (PacDriveLastCommCounter > 10000)
            {
                PacDriveLastCommCounter = 0;
            }
#if OPC_Client
            OPC_Client.JVWriteTag("CommCounter", (PacDriveLastCommCounter + 1).ToString(), false, false);
            int PacDriveCommCounter = 0;
            int.TryParse(OPC_Client.JVReadTag("CommCounter", false, false), out PacDriveCommCounter);
            bool Connected = ((PacDriveLastCommCounter + 1) == PacDriveCommCounter) ? true : false;
            PacDriveLastCommCounter = PacDriveCommCounter;

            return (Connected);
#else
            return (false);
#endif
        }

        #endregion
        //****************************************************************************************************
        public bool GetDataDumpFile(string FileName)//runs data dump upload
        {
            if (Controller.IsConnected())
            {
                if (Controller.ControllerType == (JET32XLib.CtrlType)JetControl.JetControlType.JetControl24x)
                {
                    Controller.AddDataDumpRange(255, 0, 62579, "test"); 
                    return Controller.UploadDataDumpFile(FileName);
                }
                else if (Controller.ControllerType == (JET32XLib.CtrlType)JetControl.JetControlType.JetControl64x)
                {
                    Controller.AddDataDumpRange(255, 0, 62463, "test"); 
                    return Controller.UploadDataDumpFile(FileName);
                }
                else
                    Controller.AddDataDumpRange(255, 1000000, 1119999, "test"); 
                    return Controller.UploadDataDumpFile(FileName);
            }
            else
            {
                return false;
            }

        }
        //
        //****************************************************************************************************
        public bool IsTransferRunning () //used to check transfer running state of DA upload
        {
            bool ok = false;

            if (Controller.IsConnected())
            {
                ok = Controller.IsTransferRunning();
            }
            else
            {
                ok = false;
            }
            
            return ok;
        }

        //
        //****************************************************************************************************
        public void Connect(JetControlType JetControlType, string IPAdressJetControl)
        {
            _ControllerType = JetControlType;
            _ControllerIPAddress = IPAdressJetControl;

            if (JetControlType > JetControlType.NoController && IsActive)
            {
                //Schneider PacDrive
                if (JetControlType == JetControlType.PacDrive_LMC_101)
                {
                    //Controller.Disconnect();

                    Controller.ControllerType = (JET32XLib.CtrlType)JetControlType;
                    Controller.InterfaceType = (JET32XLib.IntType)JetControlInterfaceType.JetIP;
                    Controller.IPAddress = IPAdressJetControl;
                    Controller.ReconnectInterval = ControllerReconnectInterval_ms;

#if OPC_Client
                    OPC_Client.Server = "CoDeSys.OPC.DA";
                    OPC_Client.Node = "";
                    OPC_Client.Timeout = ControllerTimeout_ms;
                    OPC_Client.UseMultithreading = true;
                    OPC_Client.Connect();

                    string LastHostByte = Controller.IPAddress.Split('.')[Controller.IPAddress.Split('.').Length - 1];
                    bool OK = OPC_Client.AddGroup("CommStates", TagGroupDataChangeUpdateTime_ms, true);
                    OK = OPC_Client.MapJVItemToItem("CommCounter", "PacDrive" + LastHostByte + ".Application.UI_VARIABLES.G_di_UICommCounter");
                    OK = OPC_Client.JVAddItem("CommStates", "CommCounter", 0, false);

                    int.TryParse(OPC_Client.JVReadTag("CommCounter", false, false), out PacDriveLastCommCounter);
                    PacDriveIsOnline = false;
                    PacDriveLastIsOnline = true;

                    if (!PacDriveList.ContainsKey(ControllerIPAddress))
                    {
                        PacDriveList.Add(ControllerIPAddress, this);

                        oPacDriveCommTimer.Interval = new TimeSpan(0, 0, 0, 0, 1000);
                        oPacDriveCommTimer.Tick += CommStateTimer_Tick;                   
                    }
                    oPacDriveCommTimer.Start();
#endif
                }
                //Communication with Jetter PLC
                else
                {
                    Controller.ControllerType = (JET32XLib.CtrlType)JetControlType;
                    Controller.InterfaceType = (JET32XLib.IntType)JetControlInterfaceType.JetIP;
                    if ((int)Controller.ControllerType >= (int)JetControlType.JetControl340 && (int)Controller.ControllerType <= (int)JetControlType.JetControl365)
                    {
                        Controller.InterfaceType = (JET32XLib.IntType)JetControlInterfaceType.JetSTX;
                    }
                    Controller.IPAddress = IPAdressJetControl;
                    Controller.ReconnectInterval = ControllerReconnectInterval_ms;
                    Controller.TimeOut = ControllerTimeout_ms;
                    Controller.Connect();

                    if (!Controller.IsConnected())
                    {
                        Application.Current.Dispatcher.BeginInvoke((Action)(() =>
                        {
                            //work on new error message!
                            //MainWindow.HMI_Message.ShowMessage(Controller.ControllerType + " (" + (int)ControllerType + ")" + "\r\n" + Controller.IPAddress + "\r\n" + HMI_Message.GetHMIMessageText(HMI_Messages.Controller_NoConnection));
                        }));

                        //MainWindow.HMI_Message.ShowMessage(Controller.ControllerType + " (" + (int)ControllerType + ")" + "\r\n" + Controller.IPAddress + "\r\n" + HMI_Message.GetHMIMessageText(HMI_Messages.Controller_NoConnection));
                        //System.Windows.MessageBox.Show(Controller.ControllerType + " (" + (int)ControllerType + ")" + "\r\n" + Controller.IPAddress + "\r\n" + " is not Connected");
                    }
                }
            }

        }

        //
        //****************************************************************************************************
        public void Reconnect()
        {
            if (ControllerType > JetControlType.NoController)
            {
                if (ControllerType == JetControlType.PacDrive_LMC_101)
                {
#if OPC_Client
                    OPC_Client.Connect();
#endif
                }
                else
                {
                    Controller.Connect();
                }
            }


        }

        //
        //****************************************************************************************************
        public bool Disconnect(bool RemoveTags)
        {
            if (RemoveTags)
            {
                this.Tags.Clear();
            }

            bool Disconnected = false;
            if (ControllerType == JetControlType.PacDrive_LMC_101)
            {
#if OPC_Client
                Disconnected = OPC_Client.Disconnect();
                if (PacDriveList.ContainsKey(ControllerIPAddress))
                {
                    oPacDriveCommTimer.Stop();
                    oPacDriveCommTimer.IsEnabled = false;
                }
#endif            
            }
            else
            {
                Disconnected = Controller.DisconnectEx(RemoveTags);
            }

            return (Disconnected);
        }

        //
        //****************************************************************************************************
        public void MapTags(string GroupName, int TagOffset = 0, string OPC_ServerMappingName = "")
        {
            if (Controller.ControllerType > (JET32XLib.CtrlType)JetControlType.NoController)
            {
                bool bGroup = false;
                bool bMapOK = false;
                bool bAddOK = false;

                int iTag = TagOffset + 1;
                string Pointer = "";
                string BlockSize = "";

#if OPC_Client
                bGroup = (ControllerType == JetControlType.PacDrive_LMC_101) ? OPC_Client.AddGroup(GroupName, TagGroupDataChangeUpdateTime_ms, true) : Controller.AddGroup(GroupName, TagGroupDataChangeUpdateTime_ms, true);
#else
                bGroup = Controller.AddGroup(GroupName, TagGroupDataChangeUpdateTime_ms, true);
#endif


                foreach (var Tag in Tags)
                {
                    bMapOK = false;
                    bAddOK = false;

                    Pointer = (Tag.Value.RegisterIsPointer == true) ? "P" : "";
                    BlockSize = (Tag.Value.BlockSize > 0) ? "Size = '" + Tag.Value.BlockSize + "'" : "";

                    if (ControllerType == JetControlType.PacDrive_LMC_101)
                    {
                        string LastHostByte = Controller.IPAddress.Split('.')[Controller.IPAddress.Split('.').Length - 1];
                        if (Tag.Value.OPC_Variable.Contains("CommState")) //PacDrive234.__CommState
                        {
#if OPC_Client
                            bMapOK = OPC_Client.MapJVItemToItem(Tag.Key, "PacDrive" + LastHostByte + "." + Tag.Value.OPC_Variable);            
#endif
                        }
                        else
                        {
#if OPC_Client
                            if (!string.IsNullOrWhiteSpace(Tag.Value.OPC_Variable))
                            {
                                if (!string.IsNullOrWhiteSpace(OPC_ServerMappingName))
                                {
                                    bMapOK = OPC_Client.MapJVItemToItem(Tag.Key, "PacDrive" + LastHostByte + ".Application." + OPC_ServerMappingName + "." + Tag.Value.OPC_Variable);
                                }
                                else
                                {
                                    bMapOK = OPC_Client.MapJVItemToItem(Tag.Key, "PacDrive" + LastHostByte + ".Application.UI_VARIABLES." + Tag.Value.OPC_Variable);
                                }

                                if (bMapOK)
                                {
                                    bAddOK = OPC_Client.JVAddItem(GroupName, Tag.Key, iTag, Tag.Value.ActiveInDataChange);
                                } 
                            }
#endif
                        }
                    }
                    else
                    {
                        if (Tag.Value.Register > 0)
                        {
                            if (Tag.Value.RegisterType == typeof(int))
                            {
                                bMapOK = Controller.MapJVItemToItem(Tag.Key, "<JW:DTAG name='" + Pointer + "R" + Tag.Value.Register + "' " + BlockSize + " type ='INT'/>");
                            }
                            else if (Tag.Value.RegisterType == typeof(double))
                            {
                                bMapOK = Controller.MapJVItemToItem(Tag.Key, "<JW:DTAG name='" + Pointer + "R" + Tag.Value.Register + "' " + BlockSize + " type ='REAL'/>");
                            }
                            else if (Tag.Value.RegisterType == typeof(bool))
                            {
                                bMapOK = Controller.MapJVItemToItem(Tag.Key, "<JW:DTAG name='" + Pointer + "F" + Tag.Value.Register + "' " + BlockSize + " type ='BOOL'/>");
                            }
                            else if (Tag.Value.RegisterType == typeof(string))
                            {
                                bMapOK = Controller.MapJVItemToItem(Tag.Key, "<JW:DTAG name='" + Pointer + "R" + Tag.Value.Register + "' " + BlockSize + " type ='STRING'/>");
                            }

                            if (bMapOK)
                            {
                                bAddOK = Controller.JVAddItem(GroupName, Tag.Key, iTag, Tag.Value.ActiveInDataChange);
                            }
                        }
                    }
                    iTag++;
                }
                //System.Threading.Thread.Sleep(500);
            }

        }

        //
        //****************************************************************************************************
        public bool WriteTag(string TagName, dynamic Value, bool NotifyDataChange = false, bool WriteAsynchron = false)
        {
            bool OK = false;
            if (ControllerType > JetControlType.NoController)
            {
                if (Tags.ContainsKey(TagName))
                {
#if OPC_Client
                    OK = (ControllerType == JetControlType.PacDrive_LMC_101) ? OPC_Client.JVWriteTag(TagName, Value.ToString(CultureInfo.CreateSpecificCulture("en-US")), NotifyDataChange, WriteAsynchron) : Controller.JVWriteTag(TagName, Value.ToString(CultureInfo.CreateSpecificCulture("en-US")), NotifyDataChange, WriteAsynchron);
#else
                    OK = Controller.JVWriteTag(TagName, Value.ToString(CultureInfo.CreateSpecificCulture("en-US")), NotifyDataChange, WriteAsynchron);
#endif         
                }
                else
                {
                    System.Windows.MessageBox.Show("Tagname '" + TagName + "' is not in Taglist");
                }
            }
            return (OK);
        }

        //
        //****************************************************************************************************
        public dynamic ReadTag(string TagName, bool NotifyDataChange = false, bool ReadAsynchron = false)
        {
            dynamic RegisterValue = null;

            if (Tags.ContainsKey(TagName))
            {
                if (ControllerType > JetControlType.NoController)
                {
#if OPC_Client
                    RegisterValue = (ControllerType == JetControlType.PacDrive_LMC_101) ? OPC_Client.JVReadTag(TagName, NotifyDataChange, ReadAsynchron) : Controller.JVReadTag(TagName, NotifyDataChange, ReadAsynchron);
#else
                    RegisterValue = Controller.JVReadTag(TagName, NotifyDataChange, ReadAsynchron);
#endif
                    if (Tags[TagName].BlockSize < 1 && !string.IsNullOrWhiteSpace(RegisterValue) && !RegisterValue.ToString().Contains("[CSError:Jet32X]"))
                    {
                        if (Tags[TagName].RegisterType == typeof(int))
                        {
                            RegisterValue = int.Parse(RegisterValue.ToString());
                        }
                        else if (Tags[TagName].RegisterType == typeof(double))
                        {
                            RegisterValue = double.Parse(RegisterValue.ToString(), CultureInfo.CreateSpecificCulture("en-US"));
                        }
                        else if (Tags[TagName].RegisterType == typeof(bool))
                        {
                            if (ControllerType == JetControlType.PacDrive_LMC_101)
                            {
                                RegisterValue = (Convert.ToInt32(RegisterValue) == 0) ? false : true;
                            }
                            else
                            {
                                RegisterValue = (Convert.ToInt32(RegisterValue) == 1) ? true : false;
                            }
                        }
                    }
                    else
                    {
                        if (Tags[TagName].RegisterType == typeof(int))
                        {
                            RegisterValue = 0;
                        }
                        else if (Tags[TagName].RegisterType == typeof(double))
                        {
                            RegisterValue = 0.0;
                        }
                        else if (Tags[TagName].RegisterType == typeof(bool))
                        {
                            RegisterValue = false;
                        }
                        else if (Tags[TagName].RegisterType == typeof(string))
                        {
                            RegisterValue = string.Empty;
                        }
                    }
                }
                else
                {
                    if (Tags[TagName].RegisterType == typeof(int))
                    {
                        RegisterValue = 0;
                    }
                    else if (Tags[TagName].RegisterType == typeof(double))
                    {
                        RegisterValue = 0.0;
                    }
                    else if (Tags[TagName].RegisterType == typeof(bool))
                    {
                        RegisterValue = false;
                    }
                    else if (Tags[TagName].RegisterType == typeof(string))
                    {
                        RegisterValue = string.Empty;
                    }
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Tagname '" + TagName + "' is not in Taglist");
            }

            return (RegisterValue);

        }

        //
        //****************************************************************************************************
        public object ReadTagBlock(string TagName, bool NotifyDataChange = false, bool ReadAsynchron = false)
        {
            object RegisterValue = Controller.JVReadTag(TagName, NotifyDataChange, ReadAsynchron);
            if (Tags.ContainsKey(TagName) && Controller.ControllerType > (JET32XLib.CtrlType)JetControlType.NoController && !RegisterValue.ToString().Contains("[CSError:Jet32X]"))
            {
                if (Tags[TagName].BlockSize > 0)
                {
                    if (Tags[TagName].RegisterType == typeof(int))
                    {
                        //RegisterValue = int.Parse(RegisterValue.ToString());
                        string[] Temp = RegisterValue.ToString().Split(';');
                        List<int> oValues = new List<int>();
                        foreach (string Value in Temp)
                        {
                            oValues.Add(int.Parse(Value));
                        }
                        RegisterValue = oValues;

                    }
                    else if (Tags[TagName].RegisterType == typeof(double))
                    {
                        //RegisterValue = double.Parse(RegisterValue.ToString(), CultureInfo.CreateSpecificCulture("en-US"));
                        string[] Temp = RegisterValue.ToString().Split(';');
                        List<double> oValues = new List<double>();
                        foreach (string Value in Temp)
                        {
                            oValues.Add(double.Parse(Value, CultureInfo.CreateSpecificCulture("en-US")));
                        }
                        RegisterValue = oValues;
                    }
                    else if (Tags[TagName].RegisterType == typeof(bool))
                    {
                        if (Convert.ToInt32(RegisterValue) == 1)
                        {
                            RegisterValue = true;
                        }
                        else
                        {
                            RegisterValue = false;
                        }
                    }
                }
                else
                {
                    if (Tags[TagName].RegisterType == typeof(int))
                    {
                        RegisterValue = int.Parse(RegisterValue.ToString());
                    }
                    else if (Tags[TagName].RegisterType == typeof(double))
                    {
                        RegisterValue = double.Parse(RegisterValue.ToString(), CultureInfo.CreateSpecificCulture("en-US"));
                    }
                    else if (Tags[TagName].RegisterType == typeof(bool))
                    {
                        if (Convert.ToInt32(RegisterValue) == 1)
                        {
                            RegisterValue = true;
                        }
                        else
                        {
                            RegisterValue = false;
                        }
                    }
                }
            }
            else
            {
                if (Tags[TagName].RegisterType == typeof(int))
                {
                    RegisterValue = 0;
                }
                else if (Tags[TagName].RegisterType == typeof(double))
                {
                    RegisterValue = 0.0;
                }
                else if (Tags[TagName].RegisterType == typeof(bool))
                {
                    RegisterValue = false;
                }
                else if (Tags[TagName].RegisterType == typeof(string))
                {
                    RegisterValue = "";
                }

                if (!Tags.ContainsKey(TagName))
                {
                    System.Windows.MessageBox.Show("Tagname '" + TagName + "' is not in Taglist");
                }
            }

            return (RegisterValue);
        }

        //
        //****************************************************************************************************
        public bool WriteMultipleTags(string Tags, string Values, bool NotifyDataChange = false)
        {
            bool OK = false;
            OK = Controller.JVWriteMultipleTags(Tags, Values, NotifyDataChange = false);
            return (OK);
        }

        //
        //****************************************************************************************************
        public void WriteBit(string Tag, uint Bit, bool Value, bool NotifyDataChange = false, bool WriteAsynchron = false)
        {
            if (Tags.ContainsKey(Tag) && Bit < 32)
            {
                if (Tags[Tag].RegisterType == typeof(int))
                {
                    int RegisterValue = ReadTag(Tag);
                    if (Value)
                    {
                        RegisterValue |= (1 << (int)Bit);
                    }
                    else
                    {
                        RegisterValue &= ~(1 << (int)Bit);
                    }
                    WriteTag(Tag, RegisterValue, NotifyDataChange, WriteAsynchron);
                }
            }
            else
            {
                System.Windows.MessageBox.Show("Tagname '" + Tag + "' is not in Taglist");
            }
        }

        //
        //****************************************************************************************************
        public bool ReadBit(string Tag, uint Bit, bool NotifyDataChange = false, bool ReadAsynchron = false)
        {
            bool value = false;
            if (Tags.ContainsKey(Tag) && Bit < 32)
            {
                if (Tags[Tag].RegisterType == typeof(int))
                {
                    int RegisterValue = ReadTag(Tag, NotifyDataChange, ReadAsynchron);
                    BitArray oBA = new BitArray(new int[] { RegisterValue });
                    if (oBA.Get((int)Bit))
                    {
                        value = true;
                    }
                }
            }
            return (value);
        }

        //
        //****************************************************************************************************
        public void ToggleBit(string Tag, uint Bit, bool NotifyDataChange = false, bool WriteAsynchron = false)
        {
            if (Tags.ContainsKey(Tag) && Bit < 32)
            {
                if (Tags[Tag].RegisterType == typeof(int))
                {
                    int RegisterValue = ReadTag(Tag);
                    BitArray oBA = new BitArray(new int[] { RegisterValue });
                    if (oBA.Get((int)Bit))
                    {
                        RegisterValue &= ~(1 << (int)Bit);
                    }
                    else
                    {
                        RegisterValue |= (1 << (int)Bit);
                    }
                    WriteTag(Tag, RegisterValue, NotifyDataChange, WriteAsynchron);
                }
            }
        }

        //
        //****************************************************************************************************
        public static JetControlInfo GetJetControlInfo(string ControllerID)
        {
            JetControlInfo oJetControlInfo = new JetControlInfo();
            oJetControlInfo.JetControlID = "-";
            oJetControlInfo.IsActive = false;
            oJetControlInfo.IPAddress = "192.168.37.113";
            oJetControlInfo.JetControlType = JetControlType.JetControl360MC;

            if (!string.IsNullOrWhiteSpace(ControllerID))
            {
                SqlConnection oSqlConnection = new SqlConnection();
                oSqlConnection.Open();
                SqlCommand oSqlCommand = new SqlCommand("SELECT * FROM JetControlSetup WHERE ID = '" + ControllerID + "';", oSqlConnection);
                SqlDataReader oSqlDataReader = oSqlCommand.ExecuteReader();

                if (oSqlDataReader.Read())
                {
                    oJetControlInfo.JetControlID = oSqlDataReader["ID"].ToString();
                    oJetControlInfo.IsActive = ((int)oSqlDataReader["Active"] > 0) ? true : false;
                    oJetControlInfo.IPAddress = oSqlDataReader["IPAddress"].ToString();
                    oJetControlInfo.JetControlType = (JetControl.JetControlType)(int)oSqlDataReader["Type"];
                }

                oSqlDataReader.Close();
                oSqlCommand.Dispose();
                oSqlConnection.Close();
                oSqlConnection.Dispose();
            }
            return (oJetControlInfo);
        }

    }

    //****************************************************************************************************
    //
    //****************************************************************************************************
    public class JetControlInfo
    {
        public string JetControlID { get; set; }
        public string IPAddress { get; set; }
        public JetControl.JetControlType JetControlType { get; set; }
        public bool IsActive { get; set; }
    }


    //****************************************************************************************************
    //
    //****************************************************************************************************
    public class JetTag
    {
        public int Register;
        public string OPC_Variable;
        public Type RegisterType;
        public bool ActiveInDataChange;
        public bool RegisterIsPointer;
        public int BlockSize = 0;

        //public int PCNr;
        //public string PCNrText;
        //public string FieldName;


        public JetTag(int Register, Type RegisterType, bool ActiveInDataChange, bool RegisterIsPointer, int BlockSize = 0/*, int PCNr = 0, string PCNrText = "", string FieldName = ""*/)
        {
            this.Register = Register;
            this.OPC_Variable = "";
            this.RegisterType = RegisterType;
            this.ActiveInDataChange = ActiveInDataChange;
            this.RegisterIsPointer = RegisterIsPointer;
            this.BlockSize = BlockSize;
        }

        public JetTag(string OPC_Variable, Type RegisterType, bool ActiveInDataChange, bool RegisterIsPointer, int BlockSize = 0/*, int PCNr = 0, string PCNrText = "", string FieldName = ""*/)
        {
            this.Register = -1;
            this.OPC_Variable = OPC_Variable;
            this.RegisterType = RegisterType;
            this.ActiveInDataChange = ActiveInDataChange;
            this.RegisterIsPointer = RegisterIsPointer;
            this.BlockSize = BlockSize;
        }

        public JetTag(int Register, string OPC_Variable, Type RegisterType, bool ActiveInDataChange, bool RegisterIsPointer, int BlockSize = 0/*, int PCNr = 0, string PCNrText = "", string FieldName = ""*/)
        {
            this.Register = Register;
            this.OPC_Variable = OPC_Variable;
            this.RegisterType = RegisterType;
            this.ActiveInDataChange = ActiveInDataChange;
            this.RegisterIsPointer = RegisterIsPointer;
            this.BlockSize = BlockSize;
        }

    }


}
