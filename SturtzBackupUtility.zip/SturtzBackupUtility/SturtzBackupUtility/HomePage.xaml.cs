﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.IO.Compression;
using Microsoft.Win32;
using System.Windows.Diagnostics;
using System.Diagnostics;

namespace SturtzBackupUtility
{

    ///             __________________________________________________
    ///             |                                                | 
    ///             |     Sturtz Backup Utility                      |
    ///             |     Author: Nicholas Simmons                   |
    ///             |     Version: 2.3.0                             |  
    ///             |________________________________________________|


    public partial class HomePage : Window
    {
        JetControl oJetControl = new JetControl();
        JetControlSetup jetControlSetup;
        
        public static JetControl.JetControlType ControllerType = JetControl.JetControlType.JetControl365; //default controller
     
        public HomePage()
        {
            InitializeComponent();
            oJetControl.OnDataDumpFinishedEvent += DataDumpFinishedEvent;// data dump finished subscription. not used anymore, doesnt work. PLC never fires event
        }
        #region Events
        private void DataDumpFinishedEvent(JetControl jetControl, bool TransferDirection, bool Error)
        {
            Console.WriteLine(TransferDirection.ToString());

            if (Error)
            {
                Console.WriteLine(Error.ToString());
            }


        }//not used anymore, keeping for future if needed
         //**********************************************************************************************************************************
        #endregion Events
        #region Methods
        public void DataPasser(string value, string selection)
        {
            if (selection == "lblPlcType")
            {
                this.lblPlcType.Content = value;
            }
            else if (selection == "lblIpAdress")
            {
                this.lblIpAdress.Content = value;
            }
        }//used to pass data from plc config screen to main window
        //**********************************************************************************************************************************
        private void ShowProgressBar(string Visibilty)
        {
            if (Visibilty == "Visible")
            {
                pbBackProgress.Visibility = Visibility.Visible;
                pbBackProgress.IsIndeterminate = true;
                pbText.Visibility = Visibility.Visible;
            }
            else if (Visibilty == "Hide")
            {
                pbBackProgress.IsIndeterminate = false;
                pbBackProgress.Visibility = Visibility.Hidden;
                pbText.Visibility = Visibility.Hidden;
            }
            else //default to hide
            {
                pbBackProgress.IsIndeterminate = false;
                pbBackProgress.Visibility = Visibility.Hidden;
                pbText.Visibility = Visibility.Hidden;
            }
        }//shows a progress bar for backup(not dynamic, dummy bar)
        //**********************************************************************************************************************************
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();

        }//lets user drag screen around
        //**********************************************************************************************************************************
        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }//custom exit button
        //**********************************************************************************************************************************
        private void btnPlcSetup_Click(object sender, RoutedEventArgs e)
        {
            jetControlSetup = new JetControlSetup(this,this.oJetControl);//pass reference to this page's oJetcontrol
            jetControlSetup.Show();
        }//pings plc for connection check
        //**********************************************************************************************************************************
        private bool CheckEmptyText(bool ok)
        {
            ok = true;

            if (string.IsNullOrEmpty(txtCustomerName.Text))
            {
                MessageBox.Show("Please enter a customer name");
                ok = false;
            }
            if (string.IsNullOrEmpty(txtSerialNumber.Text))
            {
                MessageBox.Show("Please enter a serial number");
                ok = false;
            }
            if (cmbMachineType.SelectedIndex == -1) //nothing selected
            {
                MessageBox.Show("Please select a machine type from the drop down menu");
                ok = false;
            }
           


            return ok;  
        }//checks that no textbox is empty
        //**********************************************************************************************************************************
        private void GetControllerType(int SelectedController)//not used anymore, keeping for future if needed
        {
            switch (SelectedController)

            {
                case 9:
                    ControllerType = JetControl.JetControlType.JetControl24x;
                    break;
                case 10:
                    ControllerType = JetControl.JetControlType.JetControl64x;
                    break;
                case 24:
                    ControllerType = JetControl.JetControlType.JetControl340;
                    break;
                case 25:
                    ControllerType = JetControl.JetControlType.JetControl350;
                    break;
                case 26:
                    ControllerType = JetControl.JetControlType.JetControl360;
                    break;
                case 27:
                    ControllerType = JetControl.JetControlType.JetControl940MC;
                    break;
                case 28:
                    ControllerType = JetControl.JetControlType.JetControl360MC;
                    break;
                case 35:
                    ControllerType = JetControl.JetControlType.JetControl970MC;
                    break;
                case 53:
                    ControllerType = JetControl.JetControlType.JetControl365;
                    break;
                case 54:
                    ControllerType = JetControl.JetControlType.JetControl365MC;
                    break;
            }
           
        }
        //**********************************************************************************************************************************
        private void MachineTypeChanged(object sender, EventArgs e)//automatically selects plc type/ip address for user
        {
            if (MachineTypes.SawTypes.Contains(cmbMachineType.SelectedValue.ToString()))
            {
                lblPlcType.Content = JetControl.JetControlType.JetControl365;
                lblIpAdress.Content = Connections.MachineConnections.Saw_IP;
                ControllerType = JetControl.JetControlType.JetControl365;
                chkBufferBackup.Visibility = Visibility.Hidden;
                lblBuffer.Visibility = Visibility.Hidden;
            }
            else if (MachineTypes.WelderTypes.Contains(cmbMachineType.SelectedValue.ToString()))
            {
                lblPlcType.Content = JetControl.JetControlType.JetControl350;
                lblIpAdress.Content = Connections.MachineConnections.WelderMainPLC_IP;
                ControllerType = JetControl.JetControlType.JetControl350;
                chkBufferBackup.Visibility = Visibility.Visible;
                lblBuffer.Visibility = Visibility.Visible;
            }
            // else if cleaner...todo
        }
        //**********************************************************************************************************************************
        private void getDataDumpFile(string Filepath)
        {
            
            //respond to connection status
            if (oJetControl.IsConnected)
            {
                if (oJetControl.GetDataDumpFile(Filepath + @"\" + txtSerialNumber.Text + "_" + oJetControl.JetControlID + "_" + DateTime.Now.ToString("MMddyyyy") + ".DA"))
                {
                   
                    return;//backup created successfully
                }
                else
                {
                    MessageBox.Show("Da File Upload Failed");
                   
                }

            }
            else
            {
                MessageBox.Show("Connection Failed");
            }

        }
        //**********************************************************************************************************************************
        private bool PlcConnect(string IpAddress, string JetID, JetControl.JetControlType controlType)
        {
            bool connected = false;

            JetControl.JetControlList.Clear();
            oJetControl.JetControlID = JetID;
            oJetControl.IsActive = true;
            oJetControl.IsMessageSystemActive = true;
            oJetControl.TransferAsynchronously = true;//create seperate thread for transfers. Allows for monitoring transfer progress
            oJetControl.FireProgressEvents = true;
            oJetControl.DataDumpTransferFlags = 0x002;//turns on second flag, which auto-checks the "close Dialog on Completion"
            oJetControl.ControllerType = controlType;
            oJetControl.ControllerIPAddress = IpAddress;
            oJetControl.ShowProgressDialog = true;//shows progress on screen, also will show errors if not completed
            JetControl.JetControlList.Add(oJetControl.JetControlID, oJetControl);

            oJetControl.Connect(oJetControl.ControllerType, oJetControl.ControllerIPAddress);

            if (oJetControl.IsConnected)
            {
                connected = true;
            }
            else
            {
                oJetControl.Disconnect(true);//have to call disconnect method, errors when trying to ping again
            }
            return connected;

        }
        //**********************************************************************************************************************************
        #endregion Methods
        public async void BtnStartBackup_Click(object sender, RoutedEventArgs e)
        {
            String TempFilename;
            string TempDirectory = @"D:\_BackupTemp\";
            bool ok = false;
            
            //check if textboxs are empty and throw message
            if (CheckEmptyText(ok))
            {
                TempFilename = TempDirectory + txtCustomerName.Text.Replace(" ", "_") + "_" + txtSerialNumber.Text.Replace("-","_") + "_" + cmbMachineType.SelectedValue.ToString()+ "_" + DateTime.Now.ToString("MMddyyyy_hhmm_tt");
            }
            else
            {
                return;
            }
           
            // Step 1: Create a name for the backup folder. 
            SaveFileDialog oSaveFileDialog = new SaveFileDialog();//this brings up a file browser that lets the user change their file name to whatever they want.
            oSaveFileDialog.InitialDirectory = @"D:\";
            oSaveFileDialog.FileName = TempFilename.Substring(15);// start at 15 to get only the cust name,S/N,MachType and date/time.
            oSaveFileDialog.DefaultExt = ".zip";

        
            if (oSaveFileDialog.ShowDialog() == true)//comes back true when user clicks save on the dialog
            {
                ShowProgressBar("Visible");//show progress bar
                if (MachineTypes.SawTypes.Contains(cmbMachineType.SelectedValue.ToString()))//lookup list to find correct machine type to backup from combobox selection
                {
                    #region Saw Backup
                    
                     if (chkDaDownload.IsChecked == true) //create datadump file
                        {
                            if (PlcConnect(lblIpAdress.Content.ToString(),Connections.MachineConnections.MAIN,ControllerType))
                            {
                                getDataDumpFile(TempFilename);

                                while (oJetControl.IsTransferRunning()) //transfer still in progress, delay.
                                {
                                System.Threading.Thread.Sleep(50); //50ms
                                }

                                oJetControl.Disconnect(true);// Disconnect from PLC once backup is finished. Need for multiple PLC backups in one cycle
                            }
                            else
                            {
                            MessageBox.Show("Backup Failed!" + Environment.NewLine + "Please Use PLC Config Tool To Check Connection To PLC");//error
                            ShowProgressBar("Hide");//hide progress bar
                            oJetControl.Disconnect(true);//Have to call disconnect method. Errors when trying to ping again
                            return;//loop back around to "Main"
                            }
                       
                     }
                   
                        Task<bool> Task_SawBackup = SawBackup(TempFilename, oSaveFileDialog.FileName, TempDirectory);//create backup
                    
                        await Task.WhenAll(Task_SawBackup);//asynchronous threading, wait for Task_SawBackup to finish before continuing
                    ShowProgressBar("Hide");//hide progress bar
                    
                    MessageBox.Show("Backup Complete");//message to end-user
                    #endregion Saw Backup
                }
                else if (MachineTypes.WelderTypes.Contains(cmbMachineType.SelectedValue.ToString()))//lookup list to find correct machine type to backup from combobox selection
                {
                    #region Welder Backup
                    ShowProgressBar("Visible");//show progress bar
                    if (chkDaDownload.IsChecked == true) //create datadump file
                    {
                        if (PlcConnect(lblIpAdress.Content.ToString(), Connections.MachineConnections.MAIN, ControllerType))
                        {
                            getDataDumpFile(TempFilename);
                            while (oJetControl.IsTransferRunning()) //transfer still in progress, delay.
                            {
                                System.Threading.Thread.Sleep(50);//50 ms
                            }
                            oJetControl.Disconnect(true);// Disconnect from PLC once backup is finished. Need for multiple PLC backups in one cycle
                        }
                        else
                        {
                            MessageBox.Show("Connection To Main PLC Failed!" + Environment.NewLine + "Please Use PLC Config Tool To Check Connection To PLC");//error
                            ShowProgressBar("Hide");//hide progress bar
                            oJetControl.Disconnect(true);//Have to call disconnect method. Errors when trying to ping again
                            return;//loop back around to "Main"
                        }

                        if (cmbMachineType.SelectedValue.ToString() == "HSM-TurboFrame" || cmbMachineType.SelectedValue.ToString() == "HSM-TurboSash" || cmbMachineType.SelectedValue.ToString() == "VSM-TurboFrame" || cmbMachineType.SelectedValue.ToString() == "VSM-TurboSash")//turbo plc backup if turbo machine
                        {
                            if (PlcConnect(Connections.MachineConnections.WelderTurboPLC_IP, Connections.MachineConnections.TURBO, ControllerType))
                            {
                                getDataDumpFile(TempFilename);// -7 to eliminate D:\ and .zip from name

                                while (oJetControl.IsTransferRunning()) //transfer still in progress, delay.
                                {
                                    System.Threading.Thread.Sleep(50);//50 ms
                                }
                                oJetControl.Disconnect(true);// Disconnect from PLC once backup is finished. Need for multiple PLC backups in one cycle
                            }
                            else
                            {
                                MessageBox.Show("Connection To Turbo PLC Failed!" + Environment.NewLine + "Please Use PLC Config Tool To Check Connection To PLC");//error
                                ShowProgressBar("Hide");//hide progress bar
                                oJetControl.Disconnect(true);//Have to call disconnect method. Errors when trying to ping again
                                return;//loop back around to "Main"

                            }
                        }
                        if (chkBufferBackup.IsChecked == true) //run da backup from buffer plc
                        {
                            if (PlcConnect(Connections.MachineConnections.Buffer_IP, Connections.MachineConnections.BUFFER, ControllerType))
                            {
                                getDataDumpFile(TempFilename);// -7 to eliminate D:\ and .zip from name

                                while (oJetControl.IsTransferRunning()) //transfer still in progress, delay.
                                {
                                    System.Threading.Thread.Sleep(50);//50 ms
                                }
                                oJetControl.Disconnect(true);// Disconnect from PLC once backup is finished. Need for multiple PLC backups in one cycle
                            }
                            else
                            {
                                MessageBox.Show("Connection To Buffer PLC Failed!" + Environment.NewLine + "Please Use PLC Config Tool To Check Connection To PLC");//error
                                ShowProgressBar("Hide");//hide progress bar
                                oJetControl.Disconnect(true);//Have to call disconnect method. Errors when trying to ping again
                                return;//loop back around to "Main"

                            }
                        }
                    }

                    Task<bool> Task_WelderBackup = WelderBackup(TempFilename, oSaveFileDialog.FileName, TempDirectory);//create backup //TempFilename + " " -- robocopy workaround for file nam

                    await Task.WhenAll(Task_WelderBackup);//asynchronous threading, wait for Task_SawBackup to finish before continuing
                    ShowProgressBar("Hide");//hide progress bar
                    oJetControl.Disconnect(true);

                    MessageBox.Show("Backup Complete");//message to end-user
                    #endregion Welder Backup

                }
                //else if ((MachineTypes.CleanerTypes.Contains(cmbMachineType.SelectedValue.ToString())))
                //{
                //todo....
                //}
            }
        }//this button click event runs the main program
        //**********************************************************************************************************************************
        #region Backup Tasks              
        private Task<bool> SawBackup(string TempFile, string ZipFileName, string TempDirectory)
        {
            return Task.Factory.StartNew(() =>
            {
                bool BackupComplete = true; //return statement start as true, task handles shut off
                string DaFileName = string.Empty;

               
                Process oProcess = new Process();//this runs a cmdprompt in the background
                oProcess.StartInfo.FileName = ("robocopy");//robocopy statement

              
                //Step 2: Copy files
                foreach (string File in SawDirectory.SawFiles)
                {
                    oProcess.StartInfo.Arguments = (File + " " + TempFile + @"\" + File.Substring(3)+ " " + "/S /E");//arguments for robocopy command
                    oProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;//hide window
                    oProcess.Start();//run robocopy
                    oProcess.WaitForExit();
                }
          
                try //Step 3: check if zip file already exists and delete it. Then create new zipfile
                {
                    if (File.Exists(ZipFileName))
                    {
                        File.Delete(ZipFileName);
                    }
                    
                    ZipFile.CreateFromDirectory(TempFile, ZipFileName, CompressionLevel.Fastest, true);//create zip file
                  
                    if (Directory.Exists(TempDirectory)) //delete temp directory
                        {
                            foreach (string file in Directory.GetFiles(TempDirectory, "*.*", SearchOption.AllDirectories))//delete read only attribute from files
                            {
                            File.SetAttributes(file, FileAttributes.Normal);
                            }
                          
                            Directory.Delete(TempDirectory, true);
                        }


                }
                catch (Exception error)// started to get file access errors and would blow up program. Now, program catches error and throws message to screen
                {
                    MessageBox.Show(error.Message);
                    BackupComplete = false;
                    throw;
                }

                return (BackupComplete);
            });



        }
        //**********************************************************************************************************************************
        private Task<bool> WelderBackup(string TempFile, string ZipFileName, string TempDirectory)
        {
            return Task.Factory.StartNew(() =>
            {
                bool BackupComplete = true; //return statement start as true, task handles shut off
                string DaFileName = string.Empty;


                Process oProcess = new Process();//this runs a cmdprompt in the background
                oProcess.StartInfo.FileName = ("robocopy");//robocopy statement


                //Step 2: Copy files
                foreach (string File in WelderDirectory.WelderFiles)
                {
                    oProcess.StartInfo.Arguments = (File + " " + TempFile + @"\" + File.Substring(3) + " " + "/S /E");//arguments for robocopy command
                    oProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;//hide window
                    oProcess.Start();//run robocopy
                    oProcess.WaitForExit();
                }

                try //Step 3: check if zip file already exists and delete it. Then create new zipfile
                {
                    if (File.Exists(ZipFileName))
                    {
                        File.Delete(ZipFileName);
                    }

                    ZipFile.CreateFromDirectory(TempFile, ZipFileName, CompressionLevel.Fastest, true);//create zip file

                    if (Directory.Exists(TempDirectory)) //delete temp directory
                    {
                        foreach (string file in Directory.GetFiles(TempDirectory, "*.*", SearchOption.AllDirectories))//delete read only attribute from files
                       {
                            File.SetAttributes(file, FileAttributes.Normal);
                        }

                        Directory.Delete(TempDirectory, true);
                    }


                }
                catch (Exception error)// started to get file access errors and would blow up program. Now, program catches error and throws message to screen
                {
                    MessageBox.Show(error.Message);
                    BackupComplete = false;
                    throw;
                }

                return (BackupComplete);
            });

       


        }
    //**********************************************************************************************************************************
    private Task<bool> CleanerBackup(string TempFile, string ZipFileName, string TempDirectory) //todo....
        {
            return Task.Factory.StartNew(() =>
            {
                bool BackupComplete = true;

                Process oProcess = new Process();
                oProcess.StartInfo.FileName = ("robocopy");


                //Step 2: Copy files
                foreach (string File in CleanerDirectory.CleanerFiles)
                {
                    oProcess.StartInfo.Arguments = (File + " " + TempFile + @"\" + File.Substring(3) + " " + "/S /E");
                    oProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    oProcess.Start();
                    oProcess.WaitForExit();
                }

                try //Step 3: check if zip file already exists and delete it. Then create new zipfile
                {
                    if (File.Exists(ZipFileName))
                    {
                        File.Delete(ZipFileName);
                    }

                    ZipFile.CreateFromDirectory(TempFile, ZipFileName, CompressionLevel.Fastest, true);

                    if (Directory.Exists(TempDirectory))
                    {
                        Directory.Delete(TempDirectory, true);
                    }

                }
                catch (Exception error)
                {
                    MessageBox.Show(error.Message);
                    BackupComplete = false;
                    throw;
                }

                return (BackupComplete);
            });



        }
        //**********************************************************************************************************************************
        #endregion Backup Tasks
    
        
    }

}
