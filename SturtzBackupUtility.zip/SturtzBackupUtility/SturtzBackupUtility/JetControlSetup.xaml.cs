﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.IO.Compression;
using Microsoft.Win32;
using System.Windows.Diagnostics;
using System.Diagnostics;

namespace SturtzBackupUtility
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class JetControlSetup : Window
    {
        
        ComboBoxItem ComboSource = new ComboBoxItem();
        public static JetControl.JetControlType ControllerType = JetControl.JetControlType.JetControl365; //default controller
        private string PlcTypeLabel = "lblPlcType";
        private string IpAddressLabel = "lblIpAdress";

        HomePage homePage;
        JetControl jetControl;
        
        public JetControlSetup(HomePage _homePage, JetControl oJetControl)
        {
            InitializeComponent();
            this.homePage = _homePage;
            this.jetControl = oJetControl;
        }
        public JetControlSetup()
        {
           
           
        }
        private void UpdateIpAddress(object sender, RoutedEventArgs e)//sends ip address to main page
        {
            homePage.DataPasser(txtIpAddress.Text,IpAddressLabel);
        }

        private void cmb_SelectionChanged(object sender, SelectionChangedEventArgs e) //sends controller type to main page
        {
            switch (cmbPlcType.SelectedValue)
            {
                case 9: ControllerType = JetControl.JetControlType.JetControl24x;
                    break;
                case 10:
                    ControllerType = JetControl.JetControlType.JetControl64x;
                    break;
                case 24:
                    ControllerType = JetControl.JetControlType.JetControl340;
                    break;
                case 25:
                    ControllerType = JetControl.JetControlType.JetControl350;
                    break;
                case 26:
                    ControllerType = JetControl.JetControlType.JetControl360;
                    break;
                case 27:
                    ControllerType = JetControl.JetControlType.JetControl940MC;
                    break;
                case 28:
                    ControllerType = JetControl.JetControlType.JetControl360MC;
                    break;
                case 35:
                    ControllerType = JetControl.JetControlType.JetControl970MC;
                    break;
                case 53:
                    ControllerType = JetControl.JetControlType.JetControl365;
                    break;
                case 54:
                    ControllerType = JetControl.JetControlType.JetControl365MC;
                    break;

            }

                
            this.Dispatcher.Invoke(() =>
            {
                homePage.DataPasser(ControllerType.ToString(), PlcTypeLabel);
            });


        }

    
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            getComboBoxSelections();
            
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
                this.DragMove();

        }

        private void getComboBoxSelections() //creates a multi dimensional array for the combobox selections. value-enumerated value from JetConrol class. Text- readable text for user
        {
            List<ComboBox> comboBoxes = new List<ComboBox>();
            
                comboBoxes.Add(new ComboBox() { Value = 9, Text = "JC 24x" });
                comboBoxes.Add(new ComboBox() { Value = 10, Text = "JC 64x" });
                comboBoxes.Add(new ComboBox() { Value = 24, Text = "JC 340" });
                comboBoxes.Add(new ComboBox() { Value = 25, Text = "JC 350" });
                comboBoxes.Add(new ComboBox() { Value = 26, Text = "JC 360" });
                comboBoxes.Add(new ComboBox() { Value = 27, Text = "JC 940MC" });
                comboBoxes.Add(new ComboBox() { Value = 28, Text = "JC 360MC" });
                comboBoxes.Add(new ComboBox() { Value = 35, Text = "JC 970MC" });
                comboBoxes.Add(new ComboBox() { Value = 53, Text = "JC 365" });
                comboBoxes.Add(new ComboBox() { Value = 54, Text = "JC 365MC" });

            cmbPlcType.ItemsSource = comboBoxes;

        }
        void OutputDataReceived(object sender, DataReceivedEventArgs e) //debug
        {
            MessageBox.Show(e.Data);
        }

        private void btnPlcSetup_Click(object sender, RoutedEventArgs e)
        {
            string ConnectionStatus = string.Empty;
            if (cmbPlcType.SelectedIndex == -1 && (string.IsNullOrEmpty(txtIpAddress.ToString()))) //wanted to default this to main page settings, no reason to though.
            { //Default plc config to selected machine type
                //if (MachineTypes.SawTypes.Contains(this.ParentForm.cmbMachineType.SelectedValue.ToString()))
                {
                    //oJetControl.Connect(JetControl.JetControlType.JetControl365, Connections.MachineConnections.Saw_IP);

                }
                //else if (MachineTypes.WelderTypes.Contains(this.ParentForm.cmbMachineType.SelectedValue.ToString()))
                {
                    //oJetControl.Connect(JetControl.JetControlType.JetControl350, Connections.MachineConnections.Welder_IP);
                }

            }
            else
            {

                JetControl.JetControlList.Clear();
                jetControl.JetControlID = "MAIN";
                jetControl.IsActive = true;
                jetControl.IsMessageSystemActive = true;
                jetControl.TransferAsynchronously = true;//create seperate thread for transfers. Allows for monitoring transfer progress
                jetControl.FireProgressEvents = true;
                jetControl.ShowProgressDialog = false;// do not show progress screen. Delays are dynamically handled via IsTransferRunning()
                jetControl.ControllerType = ControllerType;
                jetControl.ControllerIPAddress = txtIpAddress.Text;
                JetControl.JetControlList.Add(jetControl.JetControlID, jetControl);

                jetControl.Connect(ControllerType, jetControl.ControllerIPAddress);



                //respond to connection status
                if (jetControl.IsConnected)
                {
                    MessageBox.Show("Connection Succesful");
                    this.Close();
                }
                else
                {
                    jetControl.Disconnect(true);//Have to call disconnect method. Errors when trying to ping again
                    MessageBox.Show("Connection Failed" + Environment.NewLine + "Controller: " + ControllerType + Environment.NewLine + "IP Address: " + txtIpAddress.Text);
                  
                }
            }
           
        }
      

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
            
        }
    }
}
